import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams, Link } from "@tanstack/react-router";
import { useTutorStore } from "@/lib/tutor-store";
import { getLessonScript } from "@/lib/lesson-scripts";
import { Whiteboard } from "./Whiteboard";
import { LiveDrawer } from "./LiveDrawer";
import { MathField, MATH_SHORTCUTS } from "./MathField";
import { BlockMath } from "react-katex";
import { insertMathOnBoard } from "@/lib/whiteboard-bridge";
import { ConceptSwitcher } from "./ConceptSwitcher";
import { getConcept, useDemoPlayer } from "@/lib/lesson-concepts";

export function LessonRoute() {
  const { moduleId } = useParams({ from: "/lesson/$moduleId" });
  const navigate = useNavigate();
  const roadmap = useTutorStore((s) => s.roadmap);
  const stepByModule = useTutorStore((s) => s.stepByModule);
  const setStep = useTutorStore((s) => s.setStep);

  const mod = roadmap?.modules.find((m) => m.id === moduleId);

  useEffect(() => {
    if (!roadmap) navigate({ to: "/" });
  }, [roadmap, navigate]);

  const script = useMemo(
    () => getLessonScript(moduleId, mod?.title ?? "Lesson"),
    [moduleId, mod?.title],
  );

  const stepIndex = stepByModule[moduleId] ?? 0;
  const safeIndex = Math.min(stepIndex, script.steps.length - 1);

  const [liveOpen, setLiveOpen] = useState(false);
  const [showMath, setShowMath] = useState(false);
  const [mathValue, setMathValue] = useState("");
  const [mathToast, setMathToast] = useState<string | null>(null);
  const [conceptId, setConceptId] = useState<string>(() => {
    if (typeof window === "undefined") return "math-canvas";
    return localStorage.getItem("lumen.concept") ?? "math-canvas";
  });
  const [demoActive, setDemoActive] = useState(false);
  const concept = getConcept(conceptId);

  useEffect(() => {
    try { localStorage.setItem("lumen.concept", conceptId); } catch { /* ignore */ }
  }, [conceptId]);

  useEffect(() => { setDemoActive(false); }, [conceptId]);

  const goto = (i: number) => setStep(moduleId, Math.max(0, Math.min(script.steps.length - 1, i)));

  const demoTick = useDemoPlayer({
    active: demoActive,
    stepIndex: safeIndex,
    total: script.steps.length,
    goto,
    onFinish: () => setDemoActive(false),
  });

  const insertShortcut = (latex: string) => setMathValue((v) => v + latex);

  const addMathToBoard = () => {
    const ok = insertMathOnBoard(mathValue);
    if (ok) {
      setMathToast("Added to your whiteboard ✨");
      setMathValue("");
      setTimeout(() => setMathToast(null), 1800);
    } else {
      setMathToast("Type some math first");
      setTimeout(() => setMathToast(null), 1500);
    }
  };

  const ConceptView = concept.Component;
  const boardTone = concept.boardTone;

  return (
    <div className="lesson-shell" data-board-tone={boardTone} data-live-open={liveOpen ? "true" : undefined}>
      {boardTone !== "hidden" && (
        <div className="lesson-canvas" data-tone={boardTone}>
          <Whiteboard persistenceKey={`lumen-${moduleId}`} />
        </div>
      )}

      <header className="lesson-topbar">
        <Link to="/roadmap" className="lesson-crumb">
          <span aria-hidden>←</span> path
        </Link>
        <div className="lesson-title-wrap">
          <h1 className="tutor-serif lesson-title">{script.title}</h1>
          <p className="lesson-eyebrow">
            Step {safeIndex + 1} of {script.steps.length} · {concept.name}
          </p>
        </div>
        <button
          className="live-launch"
          onClick={() => setLiveOpen(true)}
          aria-label="Talk to Lumen live"
        >
          <span className="live-launch-orb" aria-hidden />
          <span className="live-launch-label">
            <strong>Live</strong>
            <em>Lumen listens</em>
          </span>
        </button>
      </header>

      <div className={`concept-stage concept-stage--${concept.id}`} key={concept.id}>
        <ConceptView
          script={script}
          stepIndex={safeIndex}
          goto={goto}
          demoTick={demoTick}
          demoActive={demoActive}
          onWriteMath={() => setShowMath(true)}
          onOpenLive={() => setLiveOpen(true)}
        />
      </div>

      <ConceptSwitcher
        active={concept.id}
        onChange={setConceptId}
        demoActive={demoActive}
        onToggleDemo={() => setDemoActive((v) => !v)}
      />

      {/* Math floating panel */}
      {showMath && (
        <div className="math-panel tutor-fade-in">
          <div className="math-panel-head">
            <div>
              <p className="text-xs uppercase tracking-widest" style={{ color: "var(--tutor-muted)", letterSpacing: "0.14em" }}>
                Write math
              </p>
              <p className="text-sm" style={{ color: "var(--tutor-muted)", marginTop: 2 }}>
                Tap the buttons or type. Then send it to the whiteboard.
              </p>
            </div>
            <button
              className="math-panel-close"
              onClick={() => setShowMath(false)}
              aria-label="Close math keyboard"
            >
              ✕
            </button>
          </div>
          <div className="math-shortcuts">
            {MATH_SHORTCUTS.map((s) => (
              <button
                key={s.label}
                className="math-shortcut"
                onClick={() => insertShortcut(s.latex)}
                title={`Insert ${s.label}`}
              >
                {s.label}
              </button>
            ))}
          </div>
          <MathField value={mathValue} onChange={setMathValue} placeholder="e.g. x^2 + 3x + 2" />

          <div className="math-preview" aria-live="polite">
            {mathValue.trim() ? (
              <BlockMath math={mathValue} />
            ) : (
              <span className="math-preview-empty">
                Your equation will preview here.
              </span>
            )}
          </div>

          <div className="math-panel-actions">
            <button
              className="tutor-chip"
              onClick={() => setMathValue("")}
              disabled={!mathValue}
            >
              clear
            </button>
            <button
              className="tutor-primary-btn"
              onClick={addMathToBoard}
              disabled={!mathValue.trim()}
            >
              ➜ add to whiteboard
            </button>
          </div>
          {mathToast && <p className="math-toast tutor-fade-in">{mathToast}</p>}
        </div>
      )}

      <LiveDrawer moduleId={moduleId} open={liveOpen} onClose={() => setLiveOpen(false)} />
    </div>
  );
}